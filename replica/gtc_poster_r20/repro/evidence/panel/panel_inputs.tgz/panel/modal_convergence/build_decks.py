"""Stowed radiator panel modal mesh-convergence study (locked August design, no design change).
Geometry, material, mass model and support intent copied from lock/fea/run_final_fea.py:
 - 6061-T6 (E=68.9 GPa, nu=0.33, rho=2700), S8R quadratic shells, 7 round tubes as 16-facet polygons, fin at tube equator
 - wet panel mass = ledger radiator / 140, non-structural mass smeared uniformly; header lump on tube elements at both ends
 - 7 launch pads per tube at y = linspace(0.04, L-0.04, 7), pad length 60 mm (|y-yc|<=0.03), bottom tube line, DOF 1-3 fixed
Change vs locked decks: the y-grid has nodes exactly at every pad edge, so every mesh supports the same 60 mm pad length,
and the header-lump band is a fixed physical 70 mm end band (= locked coarse end row). Refinement is uniform in y,
across sheet strips (ns) and across each tube facet (nf), with polygon geometry unchanged.
"""
import sys,json,math
from pathlib import Path
import numpy as np
R=Path(__file__).resolve().parents[1];O=Path(__file__).parent
sys.path.insert(0,str(R/'lock/sources'));import p8a_helpers as H
G=json.load(open(R/'lock/FINAL_GEOMETRY.json'));A=G['radiator'];W=A['panel_width_m'];L=A['panel_length_m'];NT=A['NT']
rm=(A['tube_OD_m']+A['tube_ID_m'])/4;tw=(A['tube_OD_m']-A['tube_ID_m'])/2;t=A['thickness_m'];E=68.9e9;rho=2700.;wet=G['ledger_kg']['radiator']/140
CFG={'material':dict(E_Pa=E,nu=.33,rho_kg_m3=rho)}
can=json.load(open(R/'THERMAL_DIAGNOSTIC_INPUT.json'));inv=can['stages/spin1/THERMAL_SPIN1.json']['cases']['August']['T1_MPG40_nominal']['inventory']
header_lump=.225+inv['hdr_fluid']/140
import os
STATIONS=np.linspace(.04,L-.04,7);PADH=float(os.environ.get('PADH','0.03'));BAND=.07;NFACET=int(os.environ.get('NFACET','16'))
def ygrid(hy):
    bp=sorted(set([0.,L,BAND,L-BAND]+[round(y+s*PADH,12) for y in STATIONS for s in(-1,1)]))
    ys=[0.]
    for a,b in zip(bp[:-1],bp[1:]):
        n=max(1,int(math.ceil((b-a)/hy-1e-9)));ys+=list(np.linspace(a,b,n+1)[1:])
    return np.array(ys)
def patch_y(m,o,u,ys,nu,group,th):
    o=np.asarray(o,float);u=np.asarray(u,float);ey=np.array([0,1.,0])
    for b in range(len(ys)-1):
        y0,y1=ys[b],ys[b+1]
        for a in range(nu):
            def P(i,j):return o+u*((2*a+i)/(2*nu))+ey*(y0+(y1-y0)*j/2)
            c=[(0,0),(2,0),(2,2),(0,2),(1,0),(2,1),(1,2),(0,1)]
            ids=[m.node(P(*q)) for q in c];cen=P(1,1)
            area=np.linalg.norm(u)/nu*(y1-y0);m.elems.append((ids,group,float(th),area,tuple(cen)))
def model(hy,ns,nf,nfacet=None):
    nfacet=nfacet or NFACET
    m=H.Mesh();ys=ygrid(hy);centers=[(k+.5)*W/NT for k in range(NT)]
    spans=[(0,centers[0]-rm)]+[(centers[k]+rm,centers[k+1]-rm) for k in range(NT-1)]+[(centers[-1]+rm,W)]
    for lo,hi in spans:patch_y(m,(lo,0,0),(hi-lo,0,0),ys,ns,'SHEET',t)
    for x in centers:
        for j in range(nfacet):
            aa=2*math.pi*j/nfacet;bb=2*math.pi*(j+1)/nfacet
            p=np.array([x+rm*math.cos(aa),0,rm*math.sin(aa)]);q=np.array([x+rm*math.cos(bb),0,rm*math.sin(bb)])
            patch_y(m,p,q-p,ys,nf,'TUBE',tw)
    struct=sum(e[2]*e[3]*rho for e in m.elems);ar=sum(e[3] for e in m.elems);extra=(wet-struct)/ar
    end=[i for i,e in enumerate(m.elems) if e[1]=='TUBE' and (e[4][1]<BAND or e[4][1]>L-BAND)]
    endA=sum(m.elems[i][3] for i in end);ends=set(end)
    me=[e[2]*e[3]*rho+extra*e[3]+(header_lump*e[3]/endA if i in ends else 0.) for i,e in enumerate(m.elems)]
    reff=[q/(e[2]*e[3]) for q,e in zip(me,m.elems)];xyz=np.array(m.xyz);pads=[]
    for x in centers:
        for y in STATIONS:
            mask=(abs(xyz[:,0]-x)<1e-8)&(abs(xyz[:,2]+rm)<1e-8)&(abs(xyz[:,1]-y)<=PADH+1e-9)
            ids=np.where(mask)[0]+1;assert len(ids)>=3;pads.append(dict(nodes=ids.tolist(),dofs=[1,2,3]))
    return dict(mesh=m,rho_eff=reff,pads=pads,total_kg=sum(me)),struct,ys
LEVELS=[('L1',0.070,2,1),('L2',0.035,4,1),('L3',0.0175,8,2),('L4',0.00875,16,4)]
if os.environ.get('SENS'):LEVELS=[(os.environ['SENS'],0.035,4,1)]
LEGACY_MODES={'L1':None}
if __name__=='__main__':
    meta=[]
    for name,hy,ns,nf in LEVELS:
        w=O/name;w.mkdir(exist_ok=True);mdl,struct,ys=model(hy,ns,nf);m=mdl['mesh'];nn=len(m.xyz)
        H.write_inp(mdl,w/'panel.inp',CFG,steps=())
        z0=[i+1 for i,p in enumerate(m.xyz) if abs(p[2])<1e-9]
        with (w/'panel.inp').open('a') as f:
            f.write('*NSET,NSET=NSHEET\n'+'\n'.join(','.join(map(str,z0[k:k+16])) for k in range(0,len(z0),16))+'\n')
            f.write('*STEP\n*FREQUENCY\n10\n*NODE PRINT,NSET=NSHEET\nU\n*END STEP\n')
        el_dy=np.diff(ys);row=dict(level=name,target_dy_m=hy,max_dy_m=float(el_dy.max()),min_dy_m=float(el_dy.min()),sheet_elems_per_strip=ns,elems_per_tube_facet=nf,tube_facets=NFACET,pad_half_length_m=PADH,
            element='S8R',n_nodes=nn,n_elements=len(m.elems),pad_nodes_per_pad=sorted(set(len(p['nodes']) for p in mdl['pads'])),
            n_constrained_dof=sum(len(p['nodes'])*3 for p in mdl['pads']),dof_free=nn*6-sum(len(p['nodes'])*3 for p in mdl['pads']),
            total_model_kg=mdl['total_kg'],structural_metal_kg=struct,panel_wet_kg=wet,header_lump_kg=header_lump)
        meta.append(row);print(json.dumps(row),flush=True)
    (O/(f"levels_{os.environ['SENS']}.json" if os.environ.get('SENS') else 'levels.json')).write_text(json.dumps(meta,indent=2)+'\n')
