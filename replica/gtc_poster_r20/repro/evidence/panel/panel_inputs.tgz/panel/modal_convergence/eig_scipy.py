"""Independent eigen-solve of CalculiX-assembled (MATRIXSTORAGE) K and M at machine-precision ARPACK tolerance.
Also prints residual norms ||K x - lam M x|| / ||K x|| for each mode."""
import sys,json,time,numpy as np,scipy.sparse as sp,scipy.sparse.linalg as sla
def load(f,n):
    d=np.loadtxt(f) if False else np.fromfile(f,sep=' ').reshape(-1,3)
    i=d[:,0].astype(np.int64)-1;j=d[:,1].astype(np.int64)-1;v=d[:,2]
    A=sp.coo_matrix((v,(i,j)),shape=(n,n)).tocsr();D=sp.diags(A.diagonal());return (A+A.T-D).tocsc()
w=sys.argv[1];k=int(sys.argv[2]) if len(sys.argv)>2 else 20
n=sum(1 for _ in open(f'{w}/panel.dof'));t0=time.time()
K=load(f'{w}/panel.sti',n);M=load(f'{w}/panel.mas',n);t1=time.time()
sig=-(2*np.pi*10)**2   # small negative shift keeps K-sigma*M positive definite
import os
if os.environ.get('ORDER'):
    lu=sla.splu((K-sig*M).tocsc(),permc_spec=os.environ['ORDER'],options=dict(SymmetricMode=True),diag_pivot_thresh=0.0)
    OPinv=sla.LinearOperator(K.shape,matvec=lu.solve,dtype=float);print('factored',time.time()-t1,'nnzLU',lu.L.nnz+lu.U.nnz,flush=True)
    lam,X=sla.eigsh(K,k=k,M=M,sigma=sig,which='LM',tol=0,OPinv=OPinv)
else:
    lam,X=sla.eigsh(K,k=k,M=M,sigma=sig,which='LM',tol=0)
o=np.argsort(lam);lam=lam[o];X=X[:,o];t2=time.time()
res=[float(np.linalg.norm(K@X[:,q]-lam[q]*(M@X[:,q]))/np.linalg.norm(K@X[:,q])) for q in range(k)]
f=np.sqrt(lam)/(2*np.pi)
# mode-1 shape locator: largest |uz| among original shell nodes (from panel.dof node.direction map)
dof=[l.strip() for l in open(f'{w}/panel.dof')];nodes=np.array([int(float(d.split('.')[0])) for d in dof]);dirs=np.array([int(d.split('.')[1]) for d in dof])
xyz={};txt=open(f'{w}/panel.inp').read().split('*ELEMENT')[0].splitlines()[1:]
for l in txt:
    a=l.split(',');xyz[int(a[0])]=tuple(map(float,a[1:]))
shapes=[]
for q in range(min(k,4)):
    v=X[:,q];sel=np.where((dirs==3)&np.isin(nodes,list(xyz.keys())))[0];i=sel[np.argmax(abs(v[sel]))]
    shapes.append(dict(mode=q+1,max_uz_node=int(nodes[i]),xyz_m=list(xyz[int(nodes[i])])))
out=dict(case=w,n_equations=n,nnz_K_upper=int((K.nnz+n)//2),k=k,freqs_Hz=f.tolist(),rel_residuals=res,load_s=t1-t0,eig_s=t2-t1,mode_shape_peaks=shapes,solver='scipy eigsh shift-invert (ARPACK tol=machine eps, SuperLU '+os.environ.get('ORDER','COLAMD')+')')
json.dump(out,open(f'{w}/eig_scipy.json','w'),indent=1);print(json.dumps({k_:out[k_] for k_ in ['case','n_equations','eig_s']}),np.round(f[:12],4).tolist(),max(res))
