"""Collect measured native Newton / independent Warp and timestep checks; no output editing."""
import json,hashlib
from pathlib import Path
R=Path(__file__).resolve().parents[2];O=Path(__file__).parent
J=lambda p:json.load(open(p));cases=[];halves=[]
for kind,dep,cap,settle in [('solar',780,64,990),('radiator',660,1,30)]:
 a=J(O/f'results_lock/{kind}_t{dep}_dt0.01_kl5000.json');b=J(O/f'results_lock/{kind}_warp_dt0.005.json');a['actual_damping_inertia_cap']=cap;a['actual_settle_seconds']=settle
 base=max(a['peak_root_moment_newton'],a['peak_root_moment_warp']);merr=abs(b['peak_root_moment_Nm']-base)/base;ferr=abs(b['peak_root_force_N']-a['peak_root_force_warp_N'])/max(a['peak_root_force_warp_N'],1e-12)
 q=dict(kind=kind,half_step=b,relative_root_moment_difference=merr,relative_root_force_difference=ferr,threshold_relative=.10,passed=b['finite'] and b['latched']==a['n_latched_newton'] and merr<.1 and ferr<.1)
 cases.append(a);halves.append(q)
out=dict(scope='Final representative rigid solar wing and radiator column; fixed bus. Not full-wing elastic/contact/hose/fleet/launcher qualification. Width fold screened geometrically, not an independently actuated dynamics model.',cases=cases,timestep_checks=halves,passed=all(z['finite'] and z['all_latched'] and z['max_angle_diff_deg']<.01 for z in cases) and all(z['passed'] for z in halves),precision='Newton and independent Warp dynamics fp32; thermal/parity studies separately fp64',audited_reproduction_source_sha256={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [O/'run_final_newton.py',O/'experiments/phase2/fold_chain_T45.py',O/'experiments/phase2/newton_xcheck_T45.py']})
out['required_model_checks_passed']=all(z['finite'] and z['all_latched'] and z['max_angle_diff_deg']<.01 for z in cases) and all(z['relative_root_moment_difference']<.1 for z in halves)
out['reaction_force_timestep_status']='OPEN' if any(z['relative_root_force_difference']>=.1 for z in halves) else 'PASS'
(O/'NEWTON_FINAL.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(passed=out['passed'],timestep_checks=halves),indent=2))
