"""Final v3 finite geometry. Rigid-body transforms retained from the historical
fleet_kin_T45 renderer, with final canonical dimensions and the four-to-six-section
fold-spacing bug fixed. This is a geometry screen, not a contact dynamics solve.
"""
import os,json,math
from pathlib import Path
import numpy as np
G=json.load(open(os.environ.get('LOCK_GEOMETRY_FILE',Path(__file__).with_name('FINAL_GEOMETRY.json'))))
A=G['radiator'];W=A['panel_width_m'];L=A['panel_length_m'];GAP=.004;PL=L+GAP;PW=W+GAP;ALONG=10
ACROSS=7;NCOLS={0:7,1:7};NPAN={(w,c):10 for w in [0,1] for c in range(7)};NPAN_TOT=140
Y0=1.06;Z_LO=-(7*PW-GAP)/2;Z_ARR=(7*PW-GAP)/2+.255
LEAF=G['array_wing_length_m']/20;NLEAF=20;ARRW=14.;NSEC=6;SECW=ARRW/NSEC;TH_ARR=.005;P_ARR=.006;P_RAD=.010
YOKE=True;ROOT_X=.5;ROOT_OFF=.25;YOKE_L=G['array_root_m']-ROOT_X;YOKE_DX=.09;YOKE_T=.06;YOKE_BOX=np.array([YOKE_L,.25,YOKE_T]);BUS=np.array([.7,2.,1.4975098936170215])
ARRAY_MAIN_SEAM=.023 # module-level gross area/rating retained; no mass or power credit
PLATE_BOX=np.array([LEAF-ARRAY_MAIN_SEAM,SECW,TH_ARR]);PANEL_BOX=np.array([W,L,.008]);RW=np.array([[0.,0.,-1.],[0.,1.,0.],[1.,0.,0.]])
def Rx(a): c, s = np.cos(a), np.sin(a); z, o = np.zeros_like(c), np.ones_like(c); return np.stack([np.stack([o, z, z], -1), np.stack([z, c, -s], -1), np.stack([z, s, c], -1)], -2)

def Ry(a): c, s = np.cos(a), np.sin(a); z, o = np.zeros_like(c), np.ones_like(c); return np.stack([np.stack([c, z, s], -1), np.stack([z, o, z], -1), np.stack([-s, z, c], -1)], -2)

def Rz(a): c, s = np.cos(a), np.sin(a); z, o = np.zeros_like(c), np.ones_like(c); return np.stack([np.stack([c, -s, z], -1), np.stack([s, c, z], -1), np.stack([z, z, o], -1)], -2)

def rad_chain(col, phi, n_max=ALONG, h_override=None):
    # True finite-face accordion hinges. First panel is already aligned +Y,
    # anchored at Y0; no artificial 90-degree root sweep through the bus.
    outp=[];outr=[]
    for ci,ph in zip(col,phi):
        h=np.array([0.]+[(-1. if j%2 else 1.)*ph for j in range(1,10)]) if h_override is None else np.asarray(h_override)
        beta=np.cumsum(h); d=np.c_[-np.sin(beta),np.cos(beta),np.zeros(10)]; n=np.c_[-np.cos(beta),-np.sin(beta),np.zeros(10)]
        off=np.array([0.]+[(-.005 if j%2 else .005) for j in range(1,10)])
        joint=np.array([0.,Y0,Z_LO+ci*PW+W/2]);pos=[];rot=[]
        for j in range(10):
            centre=joint+.5*PL*d[j]-off[j]*n[j]
            pos.append(centre-.5*L*d[j]-.5*W*np.array([0.,0.,1.]))
            rot.append(np.stack([np.array([0.,0.,1.]),d[j],n[j]],axis=1))
            if j<9: joint=joint+PL*d[j]+(off[j+1]-off[j])*n[j]
        outp.append(pos);outr.append(rot)
    return np.asarray(outp),np.asarray(outr)

def arr_chain(h,a):
    # Exact finite-face hinge offsets; the legacy 4*i*f global-X translation was
    # not a physical hinge and made the 6-section blocks interpenetrate.
    if YOKE:h=-np.asarray(h)
    beta=np.cumsum(h);Rl=Ry(-beta[1:]);ed=Rl[:,:,0];nd=Rl[:,:,2]
    root=np.array([ROOT_X,0.,Z_ARR])+YOKE_L*np.array([np.cos(beta[0]),0.,np.sin(beta[0])])
    cen=np.zeros((NLEAF,3));bottom=-(NSEC//2-0.5)*P_ARR;top=(NSEC-NSEC//2+0.5)*P_ARR
    # Full-fold section support planes are bottom=-15, top=21 mm. Alternating
    # main hinges produce 42/30-mm folded separations: mean 36 mm, 0.72 m/wing.
    cen[0]=root+.5*LEAF*ed[0]+bottom*(Ry(np.float64(-beta[0]))[:,2]-nd[0])
    for i in range(1,NLEAF):
        hh=bottom if (i-1)%2==0 else top
        cen[i]=cen[i-1]+.5*LEAF*(ed[i-1]+ed[i])+hh*(nd[i-1]-nd[i])
    al=np.array([-a if k%2==0 else 0. for k in range(NSEC)]);Rs=Rx(al);es=Rs[:,:,1];ns=Rs[:,:,2]
    loc=np.zeros((NSEC,3));j=NSEC//2-1;hs=P_ARR/2;sg=lambda k:1. if k%2==0 else -1.
    loc[j]=-.5*SECW*es[j]+hs*sg(j)*(np.array([0.,0.,1.])-ns[j])
    for k in range(j+1,NSEC):loc[k]=loc[k-1]+.5*SECW*(es[k-1]+es[k])+hs*sg(k-1)*(ns[k-1]-ns[k])
    for k in range(j-1,-1,-1):loc[k]=loc[k+1]-.5*SECW*(es[k]+es[k+1])-hs*sg(k)*(ns[k]-ns[k+1])
    pos=cen[:,None,:]+np.einsum('nij,sj->nsi',Rl,loc);rot=np.einsum('nij,sjk->nsik',Rl,Rs)
    return pos,rot

def yoke_pose(h):
    """pose of the yoke box (centre, R with local x along the link) in wing + frame"""
    b0 = -h[0]; d = np.array([np.cos(b0), 0, np.sin(b0)]); c = np.array([ROOT_X, 0, Z_ARR]) + 0.5 * YOKE_L * d - YOKE_DX * np.array([-np.sin(b0),0.,np.cos(b0)])
    return c, Ry(np.float64(-b0))
SIGN=np.array([1. if i%2==0 else -1. for i in range(21)]);STROKE=np.array([math.pi/2]+[math.pi]*20)
def poses(u_long=1.,u_width=1.,u_rad=1.,h=None,rad_h=None):
 h=SIGN*STROKE*(1-u_long) if h is None else np.asarray(h);pp=[];pr=[];ap=[];ar=[];yp=[];yr=[]
 for wing in [0,1]:
  Q=Rz(np.float64(wing*math.pi));p,R=rad_chain(np.arange(7),np.full(7,math.pi*(1-u_rad)),n_max=10,h_override=rad_h)
  p=p.reshape(-1,3);R=R.reshape(-1,3,3);pp.extend(p@Q.T);pr.extend(Q[None]@R)
  p,R=arr_chain(h,math.pi*(1-u_width));ap.extend(p.reshape(-1,3)@Q.T);ar.extend(Q[None]@R.reshape(-1,3,3));p,R=yoke_pose(h);yp.append(Q@p);yr.append(Q@R)
 return dict(panel_p=np.array(pp),panel_R=np.array(pr),plate_p=np.array(ap),plate_R=np.array(ar),yoke_p=np.array(yp),yoke_R=np.array(yr),bus_p=np.array([[0.,0.,0.]]),bus_R=np.eye(3)[None],pod_p=np.array([[0.,0.,-1.2673622525533288]]),pod_R=np.eye(3)[None])
def boxes(u_long,u_width,u_rad,h=None,rad_h=None):
 p=poses(u_long,u_width,u_rad,h,rad_h);names=[];cs=[];rs=[];ds=[]
 for key,dims in [('panel',PANEL_BOX),('plate',PLATE_BOX),('yoke',YOKE_BOX),('bus',BUS),('pod',np.array([.6,1.2,.9372146118721462]))]:
  c=p[key+'_p'];rot=p[key+'_R']
  if key=='panel':c=c+np.einsum('nij,j->ni',rot,np.array([W/2,L/2,0.]))
  names.extend([f'{key}_{j}' for j in range(len(c))]);cs.extend(c);rs.extend(rot);ds.extend([dims]*len(c))
 return names,np.array(cs),np.array(rs),np.array(ds)/2
