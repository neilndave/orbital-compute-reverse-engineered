"""One-dimensional exact SAT support bound for the recorded width-fold path.
Shrinking only finite opaque leaf bodies inside unchanged gross module/hinge envelopes.
Assembly masses, hinge pitch and conservative gross assembly inertia unchanged.
"""
from pathlib import Path
import sys,json,math
import numpy as np
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R/'lock/render'));import geometry_final as G
s=np.load(R/'lock/dynamics/results_lock/solar_t780_dt0.01_kl5000.npz')['h_newton'];need=G.ARRAY_MAIN_SEAM;worst=None;seen=0
for k in range(121):
 names,c,a,e=G.boxes(1.,k/120,0.,s[960+k]);world=np.einsum('nij,nj->ni',abs(a),e);ii,jj=np.triu_indices(len(c),1);mask=np.all(abs(c[jj]-c[ii])<=world[ii]+world[jj]+1e-9,axis=1)
 for i,j in zip(ii[mask],jj[mask]):
  axes=np.concatenate([a[i].T,a[j].T,np.cross(a[i].T[:,None,:],a[j].T[None,:,:]).reshape(9,3)]);nn=np.linalg.norm(axes,axis=1);axes=axes[nn>1e-10]/nn[nn>1e-10,None];gap=abs(axes@(c[j]-c[i]))-abs(axes@a[i])@e[i]-abs(axes@a[j])@e[j]
  if gap.max()>=-1e-6:continue
  seen+=1;B=np.zeros(len(axes))
  if names[i].startswith('plate_'):B+=abs(axes@a[i][:,0])/2
  if names[j].startswith('plate_'):B+=abs(axes@a[j][:,0])/2
  valid=B>1e-8;assert valid.any(),(names[i],names[j]);req=G.ARRAY_MAIN_SEAM+float(np.min((.0005-gap[valid])/B[valid]))
  if req>need:need=req;worst=dict(frame=k,a=names[i],b=names[j],required_m=req)
recommended=math.ceil(need*1000)/1000
out=dict(scope=__doc__,required_max_m=need,recommended_m=recommended,additional_axis_clearance_m=.0005,worst_pair=worst,interfering_pairs_examined=seen,gross_planform_loss_fraction=recommended/G.LEAF,local_active_surface_W_m2_required=319.7*G.LEAF/(G.LEAF-recommended),within_bounded_30mm_fix=recommended<=.030)
(R/'lock/dynamics/SEAM_REQUIREMENT.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
