"""Independent half-timestep Warp reference, identical final rigid dynamics setup.
Loads only the setup prefix of our audited final runner, not its Newton solve.
"""
import sys,json,time,os
from pathlib import Path
import numpy as np
B=Path(__file__).resolve().parent
kind=sys.argv[1];tdep=sys.argv[2];dt=sys.argv[3]
sys.argv=['run_final_newton.py',kind,tdep,dt]
ns={'__file__':str(B/'run_final_newton.py'),'__name__':'setup_only'}
s=(B/'run_final_newton.py').read_text();assert s.count('t0=time.perf_counter();rn=')==1
exec(compile(s.split('t0=time.perf_counter();rn=')[0],str(B/'run_final_newton.py'),'exec'),ns)
x=ns['X'];rw=x.warp_ref('motor',float(tdep),float(dt),tend=float(tdep)+float(os.environ.get("LOCK_SETTLE_SECONDS","180")))
out=dict(kind=kind,dt=float(dt),wall_s=rw['wall_s'],peak_root_force_N=float(rw['pk_rootF'][0]),peak_root_moment_Nm=float(rw['pk_rootM'][0]),peak_hinge_Nm=float(rw['pk_hinge'][0].max()),final_error_deg=float(np.degrees(abs(rw['dfin'][0])).max()),latched=int((rw['t_latch'][0]>=0).sum()),finite=bool(np.isfinite(rw['hist']).all()),tool='NVIDIA Warp',warp=ns['wp'].__version__,device='cuda:0',scope=__doc__)
o=B/'results_lock';o.mkdir(exist_ok=True);tag=f'{kind}_warp_dt{float(dt):g}';np.savez_compressed(o/f'{tag}.npz',h=rw['hist'][0]);(o/f'{tag}.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)
