"""Independent OBB separating-axis audit of finite 8-mm tubes and 5-mm solar blocks.
No tube headers, hinge housings, hoses, or deployed flexible deformation are certified.
Checks the representative one-spacecraft staged unfold, not a 30-spacecraft release contact solve.
"""
import os,sys,json,time,math
from pathlib import Path
import numpy as np
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R/'lock/render'));import geometry_final as G

def check(ul,uw,ur,h=None,rad_h=None):
 names,c,a,e=G.boxes(ul,uw,ur,h,rad_h);world=np.einsum('nij,nj->ni',abs(a),e);ii,jj=np.triu_indices(len(c),1);delta=c[jj]-c[ii];mask=np.all(abs(delta)<=world[ii]+world[jj]+1e-9,axis=1);ii=ii[mask];jj=jj[mask];bad=[];minsep=1e9
 for i,j in zip(ii,jj):
  axes=np.concatenate([a[i].T,a[j].T,np.cross(a[i].T[:,None,:],a[j].T[None,:,:]).reshape(9,3)]);norm=np.linalg.norm(axes,axis=1);axes=axes[norm>1e-10]/norm[norm>1e-10,None]
  gap=abs(axes@(c[j]-c[i]))-abs(axes@a[i])@e[i]-abs(axes@a[j])@e[j];sep=float(gap.max());minsep=min(minsep,sep)
  if sep < -1e-6:bad.append(dict(a=names[i],b=names[j],OBB_penetration_m=-sep))
 return bad,minsep
if __name__=="__main__":
 start=time.perf_counter();runs=[]
 for name in ['root_then_long_then_width_then_radiator']:
  worst=[];frames=[]
  NSAMP=int(os.environ.get("CLEARANCE_SAMPLES","481"))
  for s in np.linspace(0,1,NSAMP):
   ur=0.;uw=0.;ul=0.
   root=np.clip(4*s,0,1);ul=np.clip(4*s-1,0,1);uw=np.clip(4*s-2,0,1);ur=np.clip(4*s-3,0,1)
   h=G.SIGN*G.STROKE*(1-ul);h[0]=G.SIGN[0]*G.STROKE[0]*(1-root)
   bad,sep=check(ul,uw,ur,h)
   if bad:frames.append(dict(s=float(s),count=len(bad),max_penetration_m=max(z['OBB_penetration_m'] for z in bad)))
   worst+=bad
  runs.append(dict(sequence=name,samples=NSAMP,intersecting_samples=len(frames),max_OBB_penetration_m=max((x['OBB_penetration_m'] for x in worst),default=0),worst_pairs=sorted(worst,key=lambda x:-x['OBB_penetration_m'])[:10],frames=frames));print(name,runs[-1]['intersecting_samples'],runs[-1]['max_OBB_penetration_m'],flush=True)
 out=dict(scope=__doc__,results=runs,wall_s=time.perf_counter()-start,geometry='lock/render/geometry_final.py',status='PASS' if any(z['intersecting_samples']==0 for z in runs) else 'FIX REQUIRED')
 (R/'lock/dynamics/FINITE_CLEARANCE.json').write_text(json.dumps(out,indent=2)+'\n')
