"""Finite-body collision checks on recorded Newton trajectories, plus width fold.
Representative spacecraft, rigid bodies; neither continuous-time contact proof nor
full fleet release/hose/hinge/flexible-body qualification.
"""
import sys,json,time,hashlib
from pathlib import Path
import numpy as np
from finite_clearance import check
R=Path(__file__).resolve().parents[2];O=Path(__file__).parent;start=time.perf_counter()
s=np.load(O/'results_lock/solar_t780_dt0.01_kl5000.npz');r=np.load(O/'results_lock/radiator_t660_dt0.01_kl5000.npz');hf=s['h_newton'][-1];rows=[];source_hashes={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [O/'results_lock/solar_t780_dt0.01_kl5000.npz',O/'results_lock/radiator_t660_dt0.01_kl5000.npz']}
for label,seq in [('solar_Newton',[(h,0.,None) for h in s['h_newton'][:961]]),('width_fold',[(s['h_newton'][960+k],k/120,None) for k in range(121)]),('radiator_Newton',[(s['h_newton'][1080+k],1.,h) for k,h in enumerate(r['h_newton'])])]:
 badframes=[];worst=[];sep=1e9
 for k,(h,uw,rh) in enumerate(seq):
  bad,ss=check(1.,uw,0. if rh is None else 1.,h,rad_h=rh);sep=min(sep,ss)
  if bad:badframes.append(k);worst+=bad
 rows.append(dict(stage=label,samples=len(seq),intersecting_samples=len(badframes),worst_pairs=sorted(worst,key=lambda x:-x['OBB_penetration_m'])[:10],min_separating_axis_gap_m=sep))
out=dict(scope=__doc__,source_hashes=source_hashes,rows=rows,wall_s=time.perf_counter()-start,passed=all(z['intersecting_samples']==0 for z in rows),penetration_tolerance_m=1e-6)
(O/'TRACE_CLEARANCE.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2),flush=True)
