"""Prepare a new isolated Newton/Warp model; never patch a running or original job."""
from pathlib import Path
import shutil
src=Path('gtcv3_lock_jobs');r=Path('gtcv3_lock_jobs_final')
for d in ['experiments','src','results/full3d','results/audit']:
 shutil.copytree(src/d,r/d,dirs_exist_ok=True)
shutil.copy2(src/'FINAL_GEOMETRY.json',r/'FINAL_GEOMETRY.json')
p=r/'experiments/newton_array/run_array.py';s=p.read_text();s=s.replace('px, 0.0, 0.0','px, float(CHILD_OFF[i] if i>0 else 0.), 0.0').replace('-L / 2, 0.0, 0.0','-L / 2, float(CHILD_OFF[i]), 0.0');s=s.replace('p = b.add_link(xform=wp.transform_identity(), mass=float(m), com=wp.vec3(0, 0, 0)', 'p = b.add_link(xform=wp.transform_identity(), mass=float(m), com=wp.vec3(0, float(COM_OFF[i]), 0)');s=s.replace('I_OUT = outboard_I()','CHILD_OFF=np.zeros(N_HINGE); COM_OFF=np.zeros(N_HINGE)\nI_OUT = outboard_I()');p.write_text(s)
p=r/'experiments/phase2/fold_chain_T45.py';s=p.read_text();s=s.replace('KLAT = 5.0e5;',"ROOT_T=float(os.environ.get('LOCK_ROOT_SECONDS','180')); MAIN_T=float(os.environ.get('LOCK_MAIN_SECONDS','600'))\nKLAT = 2.0e4;")
s=s.replace('stroke: wp.array(dtype=float),','stroke: wp.array(dtype=float), child_: wp.array(dtype=float), com_: wp.array(dtype=float),')
s=s.replace('C[w, i, 0] = P[w, i, 0] + 0.5 * L * ca; C[w, i, 1] = P[w, i, 1] + 0.5 * L * sa','rx = 0.5 * L * ca + (child_[i]-com_[i]) * sa; ry = 0.5 * L * sa - (child_[i]-com_[i]) * ca\n            C[w, i, 0] = P[w, i, 0] + rx; C[w, i, 1] = P[w, i, 1] + ry')
s=s.replace('VC[w, i, 0] = VP[w, i, 0] - wabs * 0.5 * L * sa; VC[w, i, 1] = VP[w, i, 1] + wabs * 0.5 * L * ca','VC[w, i, 0] = VP[w, i, 0] - wabs * ry; VC[w, i, 1] = VP[w, i, 1] + wabs * rx')
s=s.replace('P[w, i + 1, 0] = P[w, i, 0] + L * ca; P[w, i + 1, 1] = P[w, i, 1] + L * sa','dy = float(0.0)\n            if i+1 < n:\n                dy = child_[i+1]-child_[i]\n            rx=L*ca-dy*sa; ry=L*sa+dy*ca\n            P[w, i + 1, 0] = P[w, i, 0] + rx; P[w, i + 1, 1] = P[w, i, 1] + ry')
s=s.replace('VP[w, i + 1, 0] = VP[w, i, 0] - wabs * L * sa; VP[w, i + 1, 1] = VP[w, i, 1] + wabs * L * ca','VP[w, i + 1, 0] = VP[w, i, 0] - wabs * ry; VP[w, i + 1, 1] = VP[w, i, 1] + wabs * rx')
pattern='''        for i in range(n):
            d = sgn[i] * th[w, i];'''
replacement='''        for i in range(n):
            if md == 1:
                dur=MAIN_T; start=ROOT_T
                if i==0:
                    dur=ROOT_T; start=0.0
                x=wp.clamp((t-start)/dur,0.0,1.0)
                u=x*x*x*(10.0-15.0*x+6.0*x*x); ud=float(0.0)
                if t>start and t<start+dur:
                    ud=30.0*x*x*(1.0-x)*(1.0-x)/dur
            d = sgn[i] * th[w, i];'''
assert pattern in s;s=s.replace(pattern,replacement)
s=s.replace('v1(SIGN), v1(STROKE), f(K)','v1(SIGN), v1(STROKE), v1(A.CHILD_OFF), v1(A.COM_OFF), f(K)');p.write_text(s)
p=r/'experiments/phase2/newton_xcheck_T45.py';s=p.read_text();s=s.replace('N = F.N',"N = F.N\nROOT_T=F.ROOT_T; MAIN_T=F.MAIN_T")
s=s.replace('tin = F.I_OUT * 5.77 * F.STROKE / tdep**2','tin = F.I_OUT * 5.77 * F.STROKE / np.where(np.arange(N)==0,ROOT_T,MAIN_T)**2')
s=s.replace('tt: wp.array(dtype=float)','tt: wp.array(dtype=wp.float64)').replace('t = tt[0]','t = float(tt[0])')
s=s.replace('x = wp.min(t / tdep, 1.0)', '''dur=MAIN_T; start=ROOT_T
        if i==0:
            dur=ROOT_T; start=0.0
        x = wp.clamp((t-start)/dur, 0.0, 1.0)''').replace('if t < tdep:','if t>start and t<start+dur:').replace('/ tdep\n','/ dur\n')
s=s.replace('tt = dev([0.0])','tt = wp.array(np.array([0.],np.float64),dtype=wp.float64)').replace('tt.assign(np.array([0.0], np.float32))','tt.assign(np.array([0.0], np.float64))')
s=s.replace('if i % rec_every == 0:',"if i % 10000 == 0: print(f'Newton t={i*dt:.1f}s / {tend:g}s',flush=True)\n        if i % rec_every == 0:")
p.write_text(s)
print('Prepared isolated finite-hinge Newton/Warp final model',r)
